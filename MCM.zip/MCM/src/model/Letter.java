package model;

public enum Letter 
{
	/* Letters*/
	A, B, C, D, E, F, G, H, I, J, K, L, M, N, O, P, Q, R, S, T, U, V, W, X, Y, Z,
	
	/* Numbers*/
	ZERO, ONE, TWO, THR, FOUR, FIVE, SIX, SEV, EIG, NINE, TEN,
	
	/* Punctuation*/
	AMPER, APOST, AT, COLON, COMM, DOLL, EQUAL, EXCL, HYPH, PARO, PARC, 
	PERI, PLUS, QUEST, QUOT, SEMI, SLASH, SPAC, UNDER  
	
}