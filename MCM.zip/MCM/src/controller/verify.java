package controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import model.Letter;
import model.MorseAudios;
import model.MorseLetters;
import model.MorsePics;

/**
 * Servlet implementation class verify
 */
@WebServlet("/verify")
public class verify extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public verify() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String word = request.getParameter("word");
		int counter = Integer.parseInt(request.getParameter("counter"));
		
		HttpSession session = request.getSession();
		
		//creates instance  of MorseLetters, which puts the word in the array
		MorseLetters mL = new MorseLetters(word);
		//here we retrieve the array with our word
		String [] submiss = mL.getSubmiss();
		//based on the counter we match the letter
		Letter let = mL.matchLetter(submiss[counter]);
		//create instance of MorseAudio class
		MorseAudios mA = new MorseAudios(let);
		//call on method to get the audio file name
		String audioFile = mA.matchAudio();
		//create instance of MorsePics class
		MorsePics mP = new MorsePics(let);
		//call on method to get pic file name
		String picFile = mP.matchPic();
		
		//create the total counts of letters in submiss
		int total = submiss.length - 1;
		
		session.setAttribute("word", word);
		session.setAttribute("mP", picFile);
		session.setAttribute("mA", audioFile);
		session.setAttribute("counter", counter);
		session.setAttribute("total", total);
		
		String url = "/result.jsp";
		
		RequestDispatcher dispatcher = request.getRequestDispatcher(url);
		dispatcher.forward(request, response);
		
	}

}